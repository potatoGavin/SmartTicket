﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NetCoreSite.Models
{
    public class User_Visitor
    {
        public int ID { get; set; }

        /// <summary>
        /// 用户账号
        /// </summary>
        public string Account { get; set; }

        /// <summary>
        /// 用户昵称
        /// </summary>
        public string NickName { get; set; }

        /// <summary>
        /// 用户真实姓名
        /// </summary>
        public string RealName { get; set; }

        /// <summary>
        /// 密码
        /// </summary>
        public string Password { get; set; }

        /// <summary>
        /// 盐值
        /// </summary>
        public string SaltCode { get; set; }

        /// <summary>
        /// 性别
        /// </summary>
        public string Gender { get; set; }

        /// <summary>
        /// 手机号
        /// </summary>
        public string Mobile { get; set; }

        /// <summary>
        /// 身份证号码
        /// </summary>
        public string IDCardNo { get; set; }

        /// <summary>
        /// 系统备注
        /// </summary>
        public string Remark { get; set; }

        public DateTime CreateDate { get; set; }

        public string CreateUserName { get; set; }

        public DateTime UpdateDate { get; set; }
        public string UpdateUserName { get; set; }

        public bool IsEnabled { get; set; }

        public bool IsDelete { get; set; }

    }
}

//Account      用户账号
//NickName      用户昵称
//RealName      用户真实姓名
//Password      密码
//SaltCode      盐值
//Gender      性别
//Mobile      手机号
//IDCardNo      身份证号码
//Remark      系统备注
//CreateDate      AAA
//CreateUserName      AAA
//UpdateDate      AAA
//UpdateUserName      AAA
//IsEnabled      AAA
//IsDelete      AAA
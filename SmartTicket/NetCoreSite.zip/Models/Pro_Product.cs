﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NetCoreSite.Models
{
    public class Pro_Product
    {
        public int ID { get; set; }

        /// <summary>
        /// 产品名称
        /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        /// 类型编码
        /// </summary>
        public string TypeCode { get; set; }

        /// <summary>
        /// 产品类别名称
        /// </summary>
        public string TypeName { get; set; }

        /// <summary>
        /// 票面价
        /// </summary>
        public string ProductPrice { get; set; }

        /// <summary>
        /// 售卖金额
        /// </summary>
        public string SellingPrice { get; set; }

        /// <summary>
        /// 生效时间
        /// </summary>
        public string StartDate { get; set; }

        /// <summary>
        /// 失效时间
        /// </summary>
        public string EndDate { get; set; }

        /// <summary>
        /// 产品描述
        /// </summary>
        public string Intraoduce { get; set; }

        /// <summary>
        /// 是否可用
        /// </summary>
        public bool IsEnabled { get; set; }


        public int UpdateUserID { get; set; }
        public string UpdateUserName { get; set; }
        public DateTime UpdateDate { get; set; }
        public int CreateUserID { get; set; }
        public string CreateUserName { get; set; }
        public DateTime CreateDate { get; set; }
        public bool IsDelete { get; set; }

        //ProductName  产品名称
        //TypeCode  类型编码
        //TypeName  产品类别名称
        //ProductPrice  票面价
        //SellingPrice  售卖金额
        //StartDate  生效时间
        //EndDate  失效时间
        //Intraoduce  产品描述
        //IsEnabled  是否可用
        //UpdateUserID
        //UpdateUserName
        //UpdateDate
        //CreateUserID
        //CreateUserName
        //CreateDate
        //IsDelete




       

    }
}

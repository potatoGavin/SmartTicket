﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using NetCoreSite.Models;
using System.Data;

namespace NetCoreSite.Controllers
{
    public class HomeController : Controller
    {
        #region show

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult WelCom()
        {
            return View();
        }

        public IActionResult ShowProduct()
        {
            return View();
        }


        public IActionResult ShowStaff()
        {
            return View();
        }

        public IActionResult Test()
        {
            return View();
        }

        #endregion

        #region data

        public IActionResult getinfo(int Page,int Rows)
        {

            var data = Helper.GetOrderList(Page,Rows);

            return new JsonResult(new {Data=data,Page=Page,Rows=Rows,Count=100 });            
        }


        public ActionResult DataToBase_Product()
        {
            //string sql = "select ";
            return View();
        }

        public string DataToBase_User()
        {
            List<User_Visitor> Resutlist = new List<User_Visitor>();
            try
            {
                string sql = @"SELECT code as Account,ChannelName as NickName,idcardname as RealName,Mobile as Mobile,IDCardNo as IDCardNo,
                                CreateDate as CreateDate,CreateDate as UpdateDate
                                 from p_verification where IDCardNo like '%199%' GROUP BY IDCardName ORDER BY Id desc limit 100 ";

                var dt = Helper.GetDataTable(sql,30);

                if (dt!=null&&dt.Rows.Count>0)
                {
                    foreach (DataRow item in dt.Rows)
                    {
                        User_Visitor model = new User_Visitor();

                        model.Account = item["Account"].ToString();
                        model.NickName = item["NickName"].ToString()+"_"+new Random().Next(10000,99999);
                        model.RealName = item["RealName"].ToString();
                        model.Password = "123456";
                        model.SaltCode = Guid.NewGuid().ToString("N");                        
                        model.Mobile = item["Mobile"].ToString();
                        model.IDCardNo = item["IDCardNo"].ToString();
                        model.Gender = Convert.ToInt32(model.IDCardNo.Substring(13, 3))%2==0?"女":"男";
                        model.Remark = "系统导入";
                        model.CreateDate = DateTime.Parse(item["CreateDate"].ToString());
                        model.CreateUserName = model.RealName;
                        model.UpdateDate = DateTime.Parse(item["CreateDate"].ToString());
                        model.UpdateUserName = model.RealName;
                        model.IsEnabled = true;
                        model.IsDelete = false;

                        Resutlist.Add(model);
                    }
                }

            }
            catch (Exception ex)
            {

                throw;
            }

            string insertsql = @"insert into user_visitor
                    (Account,NickName,RealName,Password,SaltCode,Gender,Mobile,IDCardNo,Remark,CreateDate,CreateUserName,UpdateUserName,UpdateDate,IsEnabled,IsDelete)
                    values";
            if (Resutlist != null && Resutlist.Count > 0)
            {
                foreach (var item in Resutlist)
                {
                    insertsql += string.Format("('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}','{12}',{13},{14}),",
                        item.Account,item.NickName, item.RealName, item.Password, item.SaltCode, item.Gender, 
                        item.Mobile, item.IDCardNo, item.Remark, item.CreateDate, item.CreateUserName, item.UpdateUserName, item.UpdateDate, item.IsEnabled, item.IsDelete);
                }
            }
            else
            {
                insertsql = "";
            }
            if (!string.IsNullOrEmpty(insertsql))
            {
                string conn = "server=192.168.33.154;Uid=root;Pwd=xiaojing;Database=smartticket;port=3306;charset=utf8";
                var t = Helper.Excute(insertsql.Trim(','), conn, 30);
                return "success";
            }
            return "file";
        }

        public string DataToBase_Userstaff()
        {
            List<User_Staff> Resutlist = new List<User_Staff>();
            try
            {
                string sql = @"SELECT id,code as Account,idcardname as UserName,Mobile as Mobile,IDCardNo as IDCardNo,
                                CreateDate as CreateDate,CreateDate as UpdateDate,1 as IsEnabled,0 as IsDelete
                                 from p_verification where IDCardNo like '%199%' and id<15000 GROUP BY IDCardName ORDER BY Id desc limit 50 ";

                var dt = Helper.GetDataTable(sql, 30);

                if (dt != null && dt.Rows.Count > 0)
                {
                    foreach (DataRow item in dt.Rows)
                    {
                        User_Staff model = new User_Staff();

                        model.Account = item["Account"].ToString();
                        model.UserName = item["UserName"].ToString();
                        model.Password = "123456";
                        model.SaltCode = Guid.NewGuid().ToString("N");
                        model.Mobile = item["Mobile"].ToString();
                        model.IDCardNo = item["IDCardNo"].ToString();
                        model.Gender = Convert.ToInt32(model.IDCardNo.Substring(13, 3)) % 2 == 0 ? "女" : "男";
                        model.Remark = "系统导入";
                        model.CreateDate = DateTime.Parse(item["CreateDate"].ToString());
                        model.CreateUserName = model.UserName;
                        model.UpdateDate = DateTime.Parse(item["CreateDate"].ToString());
                        model.UpdateUserName = model.UserName;
                        model.IsEnabled = true;
                        model.IsDelete = false;

                        Resutlist.Add(model);
                    }
                }

            }
            catch (Exception ex)
            {

                throw;
            }

            string insertsql = @"insert into user_staff
                    (Account,UserName,Password,SaltCode,Gender,Mobile,IDCardNo,Remark,CreateDate,CreateUserName,UpdateUserName,UpdateDate,IsEnabled,IsDelete)
                    values";
            if (Resutlist != null && Resutlist.Count > 0)
            {
                foreach (var item in Resutlist)
                {
                    insertsql += string.Format("('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}',{12},{13}),",
                        item.Account, item.UserName, item.Password, item.SaltCode, item.Gender,
                        item.Mobile, item.IDCardNo, item.Remark, item.CreateDate, item.CreateUserName, item.UpdateUserName, item.UpdateDate, item.IsEnabled, item.IsDelete);
                }
            }
            else
            {
                insertsql = "";
            }
            if (!string.IsNullOrEmpty(insertsql))
            {
                string conn = "server=192.168.33.154;Uid=root;Pwd=xiaojing;Database=smartticket;port=3306;charset=utf8";
                var t = Helper.Excute(insertsql.Trim(','), conn, 30);
                return "success";
            }
            return "file";
        }

        public string DataToBase_pro(int page=0,int type=1)
        {
            List<Pro_Product> Resutlist = new List<Pro_Product>();
            try
            {
                string sql = string.Format(@"SELECT ProductSeriesName as ProductName,ProductFee as ProductPrice,
                        SellingFee as SellingPrice,StartDate,EndDate,CreateDate
                    from mer_product 
                where isdelete=false ORDER BY id desc  limit {0},50 ", page);

                var dt = Helper.GetDataTable(sql, 30);

                if (dt != null && dt.Rows.Count > 0)
                {
                    foreach (DataRow item in dt.Rows)
                    {
                        Pro_Product model = new Pro_Product();

                        model.ProductName = item["ProductName"].ToString();
                        model.ProductPrice = item["ProductPrice"].ToString();
                        model.SellingPrice = item["SellingPrice"].ToString();
                        model.StartDate = item["StartDate"].ToString();
                        model.EndDate = item["EndDate"].ToString();
                        if (type == 1)
                        {
                            model.TypeCode = "190304434";
                            model.TypeName = "儿童票";
                        }
                        else if (type == 2)
                        {
                            model.TypeCode = "190304336";
                            model.TypeName = "成人票";
                        }
                        else
                        {
                            model.TypeCode = "181205256";
                            model.TypeName = "亲子票";
                        }
                        
                        model.Intraoduce = "系统导入";
                        model.CreateUserID = 0;
                        model.CreateDate = DateTime.Parse(item["CreateDate"].ToString());
                        model.CreateUserName = "管理员";
                        model.UpdateUserID = 0;
                        model.UpdateDate = DateTime.Parse(item["CreateDate"].ToString());
                        model.UpdateUserName = "管理员";
                        model.IsEnabled = true;
                        model.IsDelete = false;

                        Resutlist.Add(model);
                    }
                }

            }
            catch (Exception ex)
            {
                return "file";
            }

            string insertsql = @"insert into pro_product
                    (ProductName,TypeCode,TypeName,ProductPrice,SellingPrice,StartDate,EndDate,Intraoduce,UpdateUserID,
                            UpdateUserName,UpdateDate,CreateUserID,CreateUserName,CreateDate,IsEnabled,IsDelete)
                    values";
            if (Resutlist != null && Resutlist.Count > 0)
            {
                foreach (var item in Resutlist)
                {
                    insertsql += string.Format(@"('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}',
                            '{8}','{9}','{10}','{11}','{12}','{13}',{14},{15}),",
                        item.ProductName, item.TypeCode, item.TypeName, item.ProductPrice, item.SellingPrice, item.StartDate,
                        item.EndDate, item.Intraoduce, item.UpdateUserID,
                         item.UpdateUserName, item.UpdateDate, item.CreateUserID, item.CreateUserName, item.CreateDate, item.IsEnabled, item.IsDelete);
                }
            }
            else
            {
                insertsql = "";
            }
            if (!string.IsNullOrEmpty(insertsql))
            {
                string conn = "server=192.168.33.154;Uid=root;Pwd=xiaojing;Database=smartticket;port=3306;charset=utf8";
                var t = Helper.Excute(insertsql.Trim(','), conn, 30);
                return "success";
            }
            return "file";
              
        }

        #endregion
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NetCoreSite.Models
{
    public class OrderInfo
    {
        public string OrderNo { get; set; }        

        public string ECode { get; set; }


        public string MerchantName { get; set; }

        public string Mobile { get; set; }

        public string IDCardName { get; set; }

        public string IDCardNo { get; set; }

    }
}

﻿using System;
using System.Collections.Generic;
using MySql.Data.MySqlClient;
using System.Data;

namespace NetCoreSite.Models
{
    public class Helper
    {
        public static string conStr = "server=112.74.131.57;Uid=test_admin;Pwd=xiaojing001#%;Database=docom_saas;port=3306;charset=utf8";
        
        public static DataTable GetDataTalble(string sql)
        {
            using (MySqlConnection conn = new MySqlConnection(conStr))
            {
                try
                {
                    if (conn.State != ConnectionState.Open)
                    {
                        conn.Open();
                    }

                    DataSet ds = new DataSet();

                    MySqlCommand cmd = new MySqlCommand(sql, conn);
                    cmd.CommandType = CommandType.Text;
                    MySqlDataAdapter sda = new MySqlDataAdapter(cmd);
                    sda.Fill(ds);

                    if (conn.State != ConnectionState.Closed)
                    {
                        conn.Close();
                    }

                    sda.Dispose();

                    if (ds != null && ds.Tables.Count > 0)
                    {
                        return ds.Tables[0];
                    }
                }
                catch (Exception ex)
                {
                    return null;
                }                

                return null;
            }
        }

        public static DataTable GetDataTable(string sql, int commTime)
        {
            conStr = "server=10.0.0.7;Uid=root_yunyuan;Pwd=oP3311z32xhiE2xb;Database=docom_saas;port=3306; charset=utf8";
            using (MySqlConnection conn = new MySqlConnection(conStr))
            {
                DataTable dt = new DataTable();
                try
                {
                    conn.Open();
                    MySqlDataAdapter da = new MySqlDataAdapter();
                    MySqlCommand cmd = new MySqlCommand(sql, conn);
                    cmd.CommandTimeout = commTime;
                    da.SelectCommand = cmd;
                    da.Fill(dt);

                    da.Dispose();
                }
                catch (System.Data.SqlClient.SqlException ex)
                {
                    throw new Exception(ex.Message);
                }
                finally
                {
                    conn.Close();
                }
                return dt;
            }
        }

        public static bool Excute(string sql,string newconn,int commTime)
        {            
            using (MySqlConnection conn = new MySqlConnection(newconn))
            {
                DataTable dt = new DataTable();
                try
                {
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand(sql, conn);
                    cmd.ExecuteNonQuery();

                    //MySqlDataAdapter da = new MySqlDataAdapter();
                    //MySqlCommand cmd = new MySqlCommand(sql, conn);
                    //cmd.CommandTimeout = commTime;
                    //da.SelectCommand = cmd;
                    //da.Fill(dt);

                    //da.Dispose();
                    return true;
                }
                catch (Exception ex)
                {
                    var t = ex.Message;
                    //throw new Exception(ex.Message);
                    return false;
                }
                finally
                {
                    conn.Close();
                }
                
            }
           
        }

        public static List<OrderInfo> GetOrderList(int Page,int Rows)
        {
            string sql = "select OrderNo,code as ECode,MerchantName,Mobile,IDCardName,IDCardNo from p_verification where IDCardNo like '%199%' order by id desc ";

            sql += string.Format(" limit {0},{1}",(Page - 1)*Rows,Rows);
            

            List<OrderInfo> result = new List<OrderInfo>();
            try
            {
                var dt = GetDataTable(sql,3000);
                if (dt!=null&&dt.Rows.Count>0)
                {
                    foreach (DataRow item in dt.Rows)
                    {
                        OrderInfo model = new OrderInfo();

                        model.OrderNo = item["OrderNo"].ToString();
                        model.MerchantName = item["MerchantName"].ToString();
                        model.Mobile = item["Mobile"].ToString();
                        model.IDCardName = item["IDCardName"].ToString();
                        model.IDCardNo = item["IDCardNo"].ToString();
                        model.ECode = item["ECode"].ToString();
                        
                        result.Add(model);
                    }
                }

                return result;
            }
            catch (Exception ex)
            {
                return new List<OrderInfo>();
            }
        }        
    }
}
